# -*- coding: utf-8 -*-
"""
Created on Mon Jun 19 22:56:31 2023

@author: charl
"""

import pylab
import math

class Runtime:
    def __init__(self, Tn, n):
        self.Tn = Tn
        self.n = n
        self.legend = None

    def plotRuntime(self, style):
        pylab.plot(self.n, self.Tn, style, label=self.legend)


class BubbleSortRunTime(Runtime):
    def __init__(self, Tn, n):
        super().__init__(Tn, n)
        self.legend = "Bubble Sort: Tn vs n"

class SelectionSortRunTime(Runtime):
    def __init__(self, Tn, n):
        super().__init__(Tn, n)
        self.legend = "Selection Sort: Tn vs n"

class InsertionSortRunTime(Runtime):
    def __init__(self, Tn, n):
        super().__init__(Tn, n)
        self.legend = "Insertion Sort: Tn vs n"

class QuickSortRunTime(Runtime):
    def __init__(self, Tn , n):
        super().__init__(Tn, n)
        self.legend = "Quick Sort: Tn vs n"
        
        
if __name__ == "__main__":
    styles = ['r-', 'k-.','k:']
    runtimes = []
    n = [0, 50 , 100, 500, 1000, 5000, 10000, 50000, 100000]
    #n = [ 1, 2, 3, 4,5]
    Tn = [ x for x in n]
    ylogx = BubbleSortRunTime(Tn, n)
    Tn = [ x*x for x in n]
    yeqxsquare = SelectionSortRunTime(Tn, n)
    
    pylab.figure("Runtime")
    ylogx.plotRuntime(styles[0])
    yeqxsquare.plotRuntime(styles[1])
    pylab.show()
        
